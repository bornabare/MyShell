package hr.fer.oop.lab3.topic1.shell;

/**
 * Created by borna on 07/12/14.
 */
public enum CommandStatus {
    CONTINUE, EXIT;

    CommandStatus() {
    }
}
